def sum_numbers(numbers=None):
    pass